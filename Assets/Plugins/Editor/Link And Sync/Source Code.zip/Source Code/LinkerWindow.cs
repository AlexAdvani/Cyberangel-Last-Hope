﻿// Link & Sync // Copyright 2016 Kybernetik //

using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;

namespace LinkAndSync
{
    [Obfuscation(Exclude = false, Feature = "-rename", ApplyToMembers = false)]
    internal sealed class LinkerWindow : EditorWindow
    {
        /************************************************************************************************************************/

        private static Texture _WindowIcon;
        public static readonly List<LinkDisplay> LinkDisplays = new List<LinkDisplay>();
        private static ReorderableList _LinkList;
        private static bool _IsAnyLinkDirty;
        private static float _ScrollPosition;

        public static LinkerWindow Instance { get; private set; }

        /************************************************************************************************************************/

        [Obfuscation(Exclude = false, Feature = "-rename")]
        private void OnEnable()
        {
            if (_WindowIcon == null)
                _WindowIcon = AssetDatabase.LoadAssetAtPath<Texture>(ProjectWindowOverlay.AssemblyFolder + "/Icon.png");

            titleContent = new GUIContent(Utils.ProductName, _WindowIcon);
            minSize = new Vector2(340, LinkDisplay.DisplayHeight + 24);

            Link.CreateDisplays(LinkDisplays);

            _LinkList = new ReorderableList(LinkDisplays, typeof(LinkDisplay));
            _LinkList.headerHeight = 0;
            _LinkList.elementHeight = LinkDisplay.DisplayHeight;
            _LinkList.drawElementBackgroundCallback = DrawElementBackground;
            _LinkList.drawElementCallback = DrawLink;
            _LinkList.drawFooterCallback = DrawFooter;
            _LinkList.footerHeight = 16;
            _LinkList.onReorderCallback = OnReorderLinks;

            GUIUtility.keyboardControl = 0;

            Instance = this;
        }

        /************************************************************************************************************************/

        [Obfuscation(Exclude = false, Feature = "-rename")]
        private void OnGUI()
        {
            if (Event.current.type == EventType.Layout)
                return;

            _IsAnyLinkDirty = false;
            if (LinkDisplay.CurrentlyManaging == null)
            {
                // If necessary, adjust the rect to fit the scrollbar.
                Rect rect;
                float requiredHeight = LinkDisplay.DisplayHeight * LinkDisplays.Count + _LinkList.footerHeight + 8;

                // Receive scroll events.
                if (Event.current.type == EventType.ScrollWheel)
                {
                    _ScrollPosition += Event.current.delta.y * (LinkDisplay.DisplayHeight / 3);
                    _ScrollPosition = Mathf.Clamp(_ScrollPosition, 0, requiredHeight - position.height);
                    Event.current.Use();
                    return;
                }

                if (requiredHeight > position.height)
                {
                    rect = new Rect(-1, -_ScrollPosition, position.width - LinkDisplay.ScrollBarWidth + 3, position.height);
                }
                else
                {
                    rect = new Rect(-1, 0, position.width + 3, position.height);
                    _ScrollPosition = 0;
                }

                // Draw the links.
                _LinkList.DoList(rect);

                // Draw the scrollbar (if needed).
                if (requiredHeight > position.height)
                {
                    rect.x = position.width - LinkDisplay.ScrollBarWidth;
                    rect.y = 0;
                    rect.width = LinkDisplay.ScrollBarWidth;
                    rect.height = position.height;
                    _ScrollPosition = GUI.VerticalScrollbar(rect, _ScrollPosition, rect.height, 0, requiredHeight);
                }
            }
            else
            {
                LinkDisplay.CurrentlyManaging.DrawManagingMode(new Rect(0, 0, position.width, position.height));
            }

            if (EditorApplication.isCompiling)
                Repaint();
        }

        /************************************************************************************************************************/

        private void DrawElementBackground(Rect rect, int index, bool isActive, bool isFocused)
        {
            if (Event.current.type != EventType.Repaint ||
                index < 0)
                return;

            Color color = GUI.color;
            GUI.color = LinkDisplays[index].Color;

            if (isActive || isFocused)
            {
                Color c = GUI.color * 0.5f;
                c.a = 1;
                GUI.color = c;
            }

            rect.height += 2;
            ReorderableList.defaultBehaviours.boxBackground.Draw(rect, false, isActive, isActive, isFocused);

            GUI.color = color;
        }

        /************************************************************************************************************************/

        private void DrawLink(Rect rect, int index, bool isActive, bool isFocused)
        {
            LinkDisplay link = LinkDisplays[index];
            link.Draw(rect);
            if (link.IsDirty)
                _IsAnyLinkDirty = true;
            GUI.color = Color.white;
        }

        /************************************************************************************************************************/

        private void DrawFooter(Rect rect)
        {
            float xMax = rect.xMax;

            // Add.
            rect.width = 24;

            if (Event.current.type == EventType.Repaint)
                Styles.FooterBackground.Draw(rect, false, false, false, false);

            rect.yMin -= 3;
            if (GUI.Button(rect, ReorderableList.defaultBehaviours.iconToolbarPlus, ReorderableList.defaultBehaviours.preButton))
                AddLink();

            // Remove.
            rect.x = 20; rect.width = 24;
            rect.yMin += 3;
            if (Event.current.type == EventType.Repaint)
                Styles.FooterBackground.Draw(rect, false, false, false, false);

            rect.yMin -= 3;
            GUI.enabled = _LinkList.index >= 0 && _LinkList.index < _LinkList.count;
            if (GUI.Button(rect, ReorderableList.defaultBehaviours.iconToolbarMinus, ReorderableList.defaultBehaviours.preButton))
                RemoveLink(_LinkList.index);
            GUI.enabled = true;

            rect.xMin = rect.xMax - 1; rect.xMax = Mathf.Max(rect.xMax, xMax - 159);
            GUI.enabled = LinkDisplays.Count > 0;
            if (GUI.Button(rect, "Sync All", _IsAnyLinkDirty ? Styles.BoldButton : GUI.skin.button))
                SyncAll();
            GUI.enabled = true;

            rect.xMin = rect.xMax - 1; rect.xMax = xMax;
            rect.yMin += 3;
            if (Event.current.type == EventType.Repaint)
                Styles.FooterBackground.Draw(rect, false, false, false, false);

            rect.xMin += 4; rect.yMin -= 2;
            ProjectWindowOverlay.DrawToggle(rect);
        }

        /************************************************************************************************************************/

        public static void AddLink()
        {
            GUIUtility.keyboardControl = 0;
            _LinkList.index = -1;
            LinkDisplays.Add(new LinkDisplay());
            _ScrollPosition = float.MaxValue;
        }

        /************************************************************************************************************************/

        private static void RemoveLink(int index)
        {
            GUIUtility.keyboardControl = 0;

            LinkDisplay display = LinkDisplays[index];

            if (display.Target == null ||
                string.IsNullOrEmpty(display.Target.Source) ||
                string.IsNullOrEmpty(display.Target.Destination) ||
                !display.Target.HasSyncedAnything)
            {
                goto RemoveLink;
            }

            string message = string.Concat(
                "Do you want to delete the destination files created by this link?\nSource: ",
                display.Target.Source,
                "\nDestination: ",
                display.Target.Destination);

            switch (EditorUtility.DisplayDialogComplex("Remove Link?", message, "Delete Files", "Keep Files", "Cancel"))
            {
                case 0:
                    display.Target.DeleteAllDestination();
                    goto RemoveLink;
                case 1:
                    goto RemoveLink;
                default:
                    return;
            }

            RemoveLink:
            LinkDisplays.RemoveAt(index);
            if (display.Target != null)
                Link.Remove(display.Target);
        }

        /************************************************************************************************************************/

        private static void SyncAll()
        {
            GUIUtility.keyboardControl = 0;

            for (int i = 0; i < LinkDisplays.Count; i++)
                LinkDisplays[i].Sync();

            Link.SaveAll();
        }

        /************************************************************************************************************************/

        private static void OnReorderLinks(ReorderableList list)
        {
            Link.MatchDisplayOrder(LinkDisplays);
            Link.SaveAll();
        }

        /************************************************************************************************************************/

        public static void UpdateExclusionDisplay(Link link)
        {
            if (Instance != null)
            {
                for (int i = 0; i < LinkDisplays.Count; i++)
                {
                    LinkDisplay display = LinkDisplays[i];
                    if (display.Target == link)
                        display.GetExclusionsFromTarget();
                }

                Instance.Repaint();
            }
        }

        /************************************************************************************************************************/

        [MenuItem("Assets/Link and Sync/Linker Window")]
        public static void OpenWindow()
        {
            GetWindow<LinkerWindow>();
        }

        /************************************************************************************************************************/
    }
}