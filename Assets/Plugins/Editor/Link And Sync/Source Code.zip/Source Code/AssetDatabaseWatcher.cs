﻿// Link & Sync // Copyright 2016 Kybernetik //

using System.Reflection;
using UnityEditor;

namespace LinkAndSync
{
    internal sealed class AssetDatabaseWatcher : AssetPostprocessor
    {
        /************************************************************************************************************************/

        [Obfuscation(Exclude = false, Feature = "-rename")]
        private static void OnPostprocessAllAssets(string[] imported, string[] deleted, string[] movedTo, string[] movedFrom)
        {
            if (imported.Length > 0 || deleted.Length > 0 || movedTo.Length > 0)
                ProjectWindowOverlay.ClearCache();
            
            EditorApplication.delayCall -= Link.AutoSyncAll;
            EditorApplication.delayCall += Link.AutoSyncAll;
        }

        /************************************************************************************************************************/
    }
}