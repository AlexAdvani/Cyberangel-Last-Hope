﻿// Link & Sync // Copyright 2016 Kybernetik //

using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace LinkAndSync
{
    internal enum SyncMode
    {
        Manual,
        Auto,
        Notify,
    }

    [InitializeOnLoad]
    internal sealed class Link
    {
        /************************************************************************************************************************/
        #region All Links
        /************************************************************************************************************************/

        private static readonly List<Link> AllLinks = new List<Link>();

        /************************************************************************************************************************/

        public static Link Add(GUIContent source, GUIContent destination, bool twoWay, SyncMode mode, float hue, List<string> exclusions)
        {
            Link link = new Link();
            AllLinks.Add(link);
            _NeedsToSave = true;
            link.Setup(source, destination, twoWay, mode, hue, exclusions);
            return link;
        }

        /************************************************************************************************************************/

        public static void Remove(Link link)
        {
            if (AllLinks.Remove(link))
                ForceSave();
        }

        /************************************************************************************************************************/

        public static void CreateDisplays(List<LinkDisplay> displays)
        {
            displays.Clear();
            for (int i = 0; i < AllLinks.Count; i++)
                displays.Add(new LinkDisplay(AllLinks[i]));
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Fields and Properties
        /************************************************************************************************************************/

        public string Source { get; private set; }
        public string Destination { get; private set; }
        public bool TwoWay { get; set; }
        public SyncMode Mode { get; private set; }
        public System.DateTime LastSync { get; private set; }
        public float Hue { get; private set; }
        public bool IsFile { get; private set; }

        private readonly List<string>
            Exclusions = new List<string>();

        private readonly HashSet<string>
            SourceDirectories = new HashSet<string>(),
            SourceFiles = new HashSet<string>();

        private FileSystemWatcher _SourceWatcher;

        /************************************************************************************************************************/

        public Link() { }

        /************************************************************************************************************************/

        public void Setup(GUIContent source, GUIContent destination, bool twoWay, SyncMode mode, float hue, List<string> exclusions)
        {
            source.text = source.text.NormalizeSlashes();
            destination.text = destination.text.NormalizeSlashes();

            if (File.Exists(source.text))
            {
                if (!IsFile)
                {
                    DeleteAllDestination();
                    IsFile = true;
                }
            }
            else
            {
                if (IsFile)
                {
                    DeleteAllDestination();
                    IsFile = false;
                }

                source.text = source.text.EndWithSlash();
                destination.text = destination.text.EndWithSlash();
            }

            if (Destination != destination.text)
            {
                DeleteAllDestination();
                Destination = destination.text;
            }

            if (Source != source.text)
            {
                if (Utils.ToggleRelativity(source.text) == Source)
                    OnSourceRelativityChange(source.text);
                else
                    DeleteAllDestination();

                Source = source.text;
            }

            TwoWay = twoWay;
            Mode = mode;
            Hue = hue;

#if !LITE
            Exclusions.Clear();
            for (int i = 0; i < exclusions.Count; i++)
                AddExclusion(exclusions[i].NormalizeSlashes().RemoveTrailingSlashes());
            Exclusions.Sort();

            InitialiseWatcher();
#endif

            _NeedsToSave = true;
            ProjectWindowOverlay.ClearCache();
        }

        /************************************************************************************************************************/

        private void OnSourceRelativityChange(string newSource)
        {
            OnSourceRelativityChange(newSource, SourceDirectories);
            OnSourceRelativityChange(newSource, SourceFiles);
        }

        private void OnSourceRelativityChange(string newSource, HashSet<string> entries)
        {
            List<string> paths = Utils.GetList<string>();

            paths.AddRange(entries);
            entries.Clear();

            for (int i = 0; i < paths.Count; i++)
            {
                string path = paths[i];
                path = newSource + path.Substring(Source.Length, path.Length - Source.Length);
                entries.Add(path);
            }

            paths.Release();
        }

        /************************************************************************************************************************/
#if !LITE
        /************************************************************************************************************************/

        private void InitialiseWatcher()
        {
            if (Mode == SyncMode.Manual ||
                !ArePathsValid(false))
            {
                if (_SourceWatcher != null)
                {
                    _SourceWatcher.Dispose();
                    _SourceWatcher = null;
                }
            }
            else
            {
                if (_SourceWatcher == null)
                {
                    _SourceWatcher = new FileSystemWatcher();
                    SetWatcherPath();
                    _SourceWatcher.Changed += DelayAutoSync;
                    _SourceWatcher.Created += DelayAutoSync;
                    _SourceWatcher.Deleted += DelayAutoSync;
                    _SourceWatcher.Renamed += DelayAutoSync;
                    _SourceWatcher.Error += (sender, e) =>
                    {
                        Utils.LogException(Utils.TagAsBoldColored(Source, TextColor) + ": FileSystemWatcher error: ", e.GetException());
                    };
                    _SourceWatcher.IncludeSubdirectories = true;
                    _SourceWatcher.EnableRaisingEvents = true;
                }
                else SetWatcherPath();
            }
        }

        private void SetWatcherPath()
        {
            if (IsFile)
            {
                _SourceWatcher.Path = Path.GetDirectoryName(Source);
                _SourceWatcher.Filter = Path.GetFileName(Source);
            }
            else _SourceWatcher.Path = Source;
        }

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/

        public bool HasSyncedAnything
        {
            get { return SourceDirectories.Count > 0 || SourceFiles.Count > 0; }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Sync
        /************************************************************************************************************************/

        public void Sync(bool logWarnings = true)
        {
            CopyQueue.AssertEmpty();
            GatherSyncOperations(logWarnings);
            if (CopyQueue.ExecuteQueue())
                _NeedsToSave = true;
        }

        /************************************************************************************************************************/

        private void GatherSyncOperations(bool logWarnings)
        {
            if (!ArePathsValid(logWarnings))
                return;

            DebugLog("Gathering Sync Operations:\nSourceFiles: " + SourceFiles.DeepToString() +
                "\nSourceDirectories: " + SourceDirectories.DeepToString() +
                "\nExclusions: " + Exclusions.DeepToString());

#if LITE
            TwoWay = false;
            Mode = SyncMode.Manual;
#endif

            DeleteOldFiles();
            DeleteOldDirectories();

            SourceFiles.Clear();
            SourceDirectories.Clear();

            if (IsFile)
                GatherSyncFile(logWarnings);
            else
                GatherSyncFolder(logWarnings);

            LastSync = System.DateTime.Now;
            IsOutOfDate = false;
        }

        /************************************************************************************************************************/

        public void FullReimport()
        {
            DeleteAllDestination();
            SourceDirectories.Clear();
            SourceFiles.Clear();
            Sync();
            ForceSave();
        }

        /************************************************************************************************************************/

        public static void SyncAll()
        {
            CopyQueue.AssertEmpty();

            for (int i = 0; i < AllLinks.Count; i++)
                AllLinks[i].GatherSyncOperations(true);

            if (CopyQueue.ExecuteQueue() || _NeedsToSave)
                SaveAll();
        }

        /************************************************************************************************************************/
        #region File Sync
        /************************************************************************************************************************/

        private void GatherSyncFile(bool logWarnings)
        {
            if (!File.Exists(Source))
            {
                if (logWarnings)
                    Debug.LogWarning(Utils.LogPrefix + "unable to sync link " + GetColoredDescription() + " because the source file doesn't exist.");
                return;
            }

            string directory = Path.GetDirectoryName(Destination);
            if (!Directory.Exists(directory))
            {
                CopyQueue.AddDirectory(directory);
                CopyQueue.AddFile(Source, Destination);
            }
            else
            {
                GatherFile(Source, Destination, false);
            }

            GatherSourceMeta();
        }

        /************************************************************************************************************************/

        private void GatherFile(string sourceFile, string destinationFile, bool canDeleteSource)
        {
            var sourceModified = File.GetLastWriteTime(sourceFile);
            var destinationModified = File.GetLastWriteTime(destinationFile);

#if !LITE
            if (TwoWay)
            {
                if (sourceModified > destinationModified)
                {
                    if (sourceModified > LastSync || !canDeleteSource)
                        CopyQueue.AddFile(sourceFile, destinationFile, sourceModified);
                    else
                        DeleteFile(sourceFile);
                }
                else if (destinationModified > sourceModified)
                {
                    if (destinationModified > LastSync)
                        CopyQueue.AddFile(destinationFile, sourceFile, destinationModified);
                    else
                        DeleteAsset(destinationFile);
                }
            }
            else
#endif
            {
                if (sourceModified != destinationModified)
                    CopyQueue.AddFile(sourceFile, destinationFile, sourceModified);
            }
        }

        /************************************************************************************************************************/

        private bool GatherFile(string sourceFile)
        {
            if (IsExcluded(sourceFile) ||
                IsMetaWithoutTarget(sourceFile))
                return false;

            GatherFile(sourceFile, SourceToDestination(sourceFile), true);
            return true;
        }

        /************************************************************************************************************************/

        private void GatherSourceMeta()
        {
            string source = IsFile ? Source : Source.Substring(0, Source.Length - 1);
            string meta = source + ".meta";
            if (!File.Exists(meta))
                return;

            string destination = IsFile ? Destination : Destination.Substring(0, Destination.Length - 1);
            GatherFile(meta, Utils.ConvertSubPath(meta, source, destination), TwoWay);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Folder Sync
        /************************************************************************************************************************/

        private void GatherSyncFolder(bool logWarnings)
        {
            if (!Directory.Exists(Source))
            {
                if (logWarnings)
                    Debug.LogWarning(Utils.LogPrefix + "unable to sync link " + GetColoredDescription() + " because the source directory doesn't exist.");
                return;
            }

#if !LITE
            if (TwoWay)
                GatherDirectoryTwoWay(Source, Destination);
            else
#endif
                GatherDirectoryOneWay(Source);

            GatherSourceMeta();
        }

        /************************************************************************************************************************/

        private void GatherDirectoryOneWay(string sourceDirectory)
        {
            string destination = SourceToDestination(sourceDirectory);
            if (!Directory.Exists(destination))
                CopyQueue.AddDirectory(destination);

            string[] files = Directory.GetFiles(sourceDirectory);
            for (int i = 0; i < files.Length; i++)
            {
                string file = files[i];
                if (GatherFile(file))
                    SourceFiles.Add(file);
            }

            files = Directory.GetDirectories(sourceDirectory);
            for (int i = 0; i < files.Length; i++)
            {
                sourceDirectory = files[i];

                if (IsExcluded(sourceDirectory))
                    continue;

                SourceDirectories.Add(sourceDirectory);

                GatherDirectoryOneWay(sourceDirectory);
            }
        }

        /************************************************************************************************************************/

        private void GatherDirectoryTwoWay(string sourceDirectory, string destinationDirectory)
        {
            // Gather Files.

            string[] sourceFiles = Directory.GetFiles(sourceDirectory);
            string[] destinationFiles = Directory.GetFiles(destinationDirectory);

            // TODO: optimise using an incremental search based on the result from string.Compare.
            for (int i = 0; i < sourceFiles.Length; i++)
            {
                string sourceFile = sourceFiles[i];
                if (IsExcluded(sourceFile) ||
                    IsMetaWithoutTarget(sourceFile))
                    continue;

                SourceFiles.Add(sourceFile);

                string destinationFile = GrabDestination(sourceFile, destinationFiles);
                if (destinationFile != null)
                {
                    GatherFile(sourceFile, destinationFile, true);
                }
                else// The destination file doesn't exist.
                {
                    CopyQueue.AddFile(sourceFile, SourceToDestination(sourceFile));
                }
            }

            // For any destination files that weren't already paired with a source file, copy them to the source.
            for (int i = 0; i < destinationFiles.Length; i++)
            {
                string destinationFile = destinationFiles[i];
                if (destinationFile == null || IsExcluded(destinationFile, Destination))
                    continue;

                string sourceFile = DestinationToSource(destinationFile);
                SourceFiles.Add(sourceFile);
                CopyQueue.AddFile(destinationFile, sourceFile);
            }

            // Gather Subdirectories.

            sourceFiles = Directory.GetDirectories(sourceDirectory);
            destinationFiles = Directory.GetDirectories(destinationDirectory);

            for (int i = 0; i < sourceFiles.Length; i++)
            {
                sourceDirectory = sourceFiles[i];
                if (IsExcluded(sourceDirectory))
                    continue;

                SourceDirectories.Add(sourceDirectory);

                destinationDirectory = GrabDestination(sourceDirectory, destinationFiles);
                if (destinationDirectory != null)
                {
                    GatherDirectoryTwoWay(sourceDirectory, destinationDirectory);
                }
                else// The destination directory doesn't exist.
                {
                    CopyQueue.AddDirectoryRecursive(sourceDirectory, SourceToDestination(sourceDirectory), true, SourceFiles, SourceDirectories);
                }
            }

            // For any destination directories that weren't already paired with a source directory, copy them to the source.
            for (int i = 0; i < destinationFiles.Length; i++)
            {
                destinationDirectory = destinationFiles[i];
                if (destinationDirectory == null || IsExcluded(destinationDirectory, Destination))
                    continue;

                sourceDirectory = DestinationToSource(destinationDirectory);
                SourceDirectories.Add(sourceDirectory);
                CopyQueue.AddDirectoryRecursive(destinationDirectory, sourceDirectory, false, SourceFiles, SourceDirectories);
            }
        }

        /************************************************************************************************************************/

        private string GrabDestination(string source, string[] destinations)
        {
            for (int i = 0; i < destinations.Length; i++)
            {
                string destination = destinations[i];
                if (destination == null)
                    continue;

                if (source.Length - Source.Length == destination.Length - Destination.Length &&
                    string.Compare(source, Source.Length + 1, destination, Destination.Length + 1, source.Length - (Source.Length + 1)) == 0)
                {
                    destinations[i] = null;
                    return destination;
                }
            }

            return null;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Old File Deletion
        /************************************************************************************************************************/

        /// <summary>
        /// If anything in SourceFiles doesn't exist, delete its destination.
        /// </summary>
        private void DeleteOldFiles()
        {
            if (SourceFiles.Count == 0)
                return;

#if !LITE
            if (TwoWay)
            {
                foreach (var sourceFile in SourceFiles)
                {
                    string destinationFile = SourceToDestination(sourceFile);
                    if (IsExcluded(sourceFile))
                    {
                        DeleteFile(sourceFile);
                        DeleteAsset(destinationFile);
                    }
                    else if (!File.Exists(sourceFile))
                    {
                        DeleteAsset(destinationFile);
                    }
                    else if (!File.Exists(destinationFile))
                    {
                        DeleteFile(sourceFile);
                    }
                }
            }
            else// One Way.
#endif
            {
                foreach (var sourceFile in SourceFiles)
                {
                    if (!File.Exists(sourceFile) || IsExcluded(sourceFile))
                    {
                        DebugLog(sourceFile);
                        DeleteAsset(SourceToDestination(sourceFile));
                    }
                }
            }
        }

        /************************************************************************************************************************/

        private void DeleteAsset(string path)
        {
            _NeedsToSave = true;

            DebugLog("Deleting File: " + path);

            if (Utils.IsReadyForProgress()) Utils.DisplayProgressBar("Deleting: " + path, 0);

            if (AssetDatabase.DeleteAsset(path))
                return;

            if (File.Exists(path))
                File.Delete(path);
        }

        private void DeleteFile(string path)
        {
            _NeedsToSave = true;

            DebugLog("Deleting File: " + path);

            if (Utils.IsReadyForProgress()) Utils.DisplayProgressBar("Deleting: " + path, 0);

            if (File.Exists(path))
                File.Delete(path);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// If anything in SourceDirectories doesn't exist, delete its destination.
        /// </summary>
        private void DeleteOldDirectories()
        {
            if (SourceDirectories.Count == 0)
                return;

            List<string> foldersToDelete = Utils.GetList<string>();

#if !LITE
            if (TwoWay)
            {
                foreach (var sourceDirectory in SourceDirectories)
                {
                    string destinationDirectory = SourceToDestination(sourceDirectory);
                    if (IsExcluded(sourceDirectory))
                    {
                        foldersToDelete.Add(sourceDirectory);
                        foldersToDelete.Add(destinationDirectory);
                    }
                    else if (!Directory.Exists(sourceDirectory))
                    {
                        foldersToDelete.Add(destinationDirectory);
                    }
                    else if (!Directory.Exists(destinationDirectory))
                    {
                        foldersToDelete.Add(sourceDirectory);
                    }
                }
            }
            else// One Way.
#endif
            {
                foreach (var sourceDirectory in SourceDirectories)
                {
                    if (!Directory.Exists(sourceDirectory) || IsExcluded(sourceDirectory))
                    {
                        foldersToDelete.Add(SourceToDestination(sourceDirectory));
                    }
                }
            }

            Utils.SortDeepestFirst(foldersToDelete);
            for (int i = 0; i < foldersToDelete.Count; i++)
            {
                DebugLog("Deleting Directory: " + foldersToDelete[i]);

                if (Utils.DeleteIfEmpty(foldersToDelete[i]))
                    _NeedsToSave = true;
            }

            foldersToDelete.Release();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Delete the destinations of everything in SourceFiles and SourceDirectories.
        /// </summary>
        public void DeleteAllDestination()
        {
            if (!HasSyncedAnything)
                return;

            DebugLog("Deleting everything at the destination");

            try
            {
                AssetDatabase.StartAssetEditing();

                // Delete all files.
                foreach (var file in SourceFiles)
                    DeleteAsset(SourceToDestination(file));
                SourceFiles.Clear();

                // Only delete empty directories.
                List<string> directories = Utils.GetList<string>();
                foreach (var directory in SourceDirectories)
                    directories.Add(SourceToDestination(directory));

                Utils.SortDeepestFirst(directories);
                for (int i = 0; i < directories.Count; i++)
                    Utils.DeleteIfEmpty(directories[i]);

                directories.Release();
                SourceDirectories.Clear();

                // Delete the Destination folder if it is empty.
                if (!IsFile)
                    Utils.DeleteIfEmpty(Destination);
            }
            catch (System.Exception ex)
            {
                Utils.LogException(GetColoredDescription() + ": unable to delete linked files: ", ex);
            }

            AssetDatabase.StopAssetEditing();
            AssetDatabase.Refresh();
            ProjectWindowOverlay.ClearCache();
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Auto Sync
        /************************************************************************************************************************/

        private void AutoSyncGather()
        {
#if !LITE
            switch (Mode)
            {
                case SyncMode.Auto:
                    if (!EditorApplication.isCompiling)
                        GatherSyncOperations(false);
                    break;
                case SyncMode.Notify:
                    if (!IsOutOfDate && CheckIfOutOfDate())
                    {
                        IsOutOfDate = true;
                        Color color = TextColor;

                        StringBuilder text = new StringBuilder();
                        text.Append(Utils.LogPrefix + "the link ");
                        AppendColoredDescription(text);
                        text.Append(" is out of date and needs to be synchronised.");

                        Debug.LogWarning(text, GetContext());
                    }
                    break;
                case SyncMode.Manual:
                    break;
            }
#endif
        }

        private void AutoSyncExecute()
        {
#if !LITE
            CopyQueue.AssertEmpty();
            AutoSyncGather();
            if (CopyQueue.ExecuteQueue() || _NeedsToSave)
                SaveAll();
#endif
        }

        private void DelayAutoSync(object sender, FileSystemEventArgs e)
        {
            EditorApplication.delayCall -= AutoSyncExecute;
            EditorApplication.delayCall += AutoSyncExecute;
        }

        /************************************************************************************************************************/

        public Color TextColor
        {
            get { return Utils.HSBtoRGB(Hue, 1, 0.5f); }
        }

        /************************************************************************************************************************/

        public void AppendColoredDescription(StringBuilder text)
        {
            Color color = TextColor;
            text.Append("from ");
            Utils.AppendBoldColored(text, color, Source);
            text.Append(" to ");
            Utils.AppendBoldColored(text, color, Destination);
        }

        public string GetColoredDescription()
        {
            StringBuilder text = new StringBuilder();
            AppendColoredDescription(text);
            return text.ToString();
        }

        /************************************************************************************************************************/

        public static void AutoSyncAll()
        {
            // If playing, sync when you stop, otherwise sync now.
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                EditorApplication.playmodeStateChanged -= AutoSyncAll;
                EditorApplication.playmodeStateChanged += AutoSyncAll;
                return;
            }

            CopyQueue.AssertEmpty();

            for (int i = 0; i < AllLinks.Count; i++)
                AllLinks[i].AutoSyncGather();

            if (CopyQueue.ExecuteQueue() || _NeedsToSave)
                SaveAll();
        }

        /************************************************************************************************************************/

        private static void AskIfAutoSyncIsAllowed()
        {
            string path = System.Environment.CurrentDirectory + @"\Temp\" + Utils.ProductName;
            if (File.Exists(path))
                return;

            File.WriteAllText(path, "");

            for (int i = 0; i < AllLinks.Count; i++)
                if (AllLinks[i].Mode == SyncMode.Auto)
                    goto Continue;

            return;

            Continue:

            StringBuilder text = new StringBuilder();
            text.AppendLine("The following links are using Auto mode:");
            for (int i = 0; i < AllLinks.Count; i++)
            {
                Link link = AllLinks[i];
                if (link.Mode == SyncMode.Auto)
                {
                    text.Append("  ").AppendLine(link.Source);
                }
            }
            text.AppendLine();
            text.Append("Would you like to allow them to synchronise automatically? (if unsure, select Disable Auto to be safe)");

            if (!EditorUtility.DisplayDialog(Utils.ProductName, text.ToString(), "Allow Auto", "Disable Auto"))
            {
                for (int i = 0; i < AllLinks.Count; i++)
                {
                    Link link = AllLinks[i];
                    if (link.Mode == SyncMode.Auto)
                        link.Mode = SyncMode.Notify;
                }

                ForceSave();
            }
        }

        /************************************************************************************************************************/
        #region Notify Mode
        /************************************************************************************************************************/

        /// <summary>Only set in <see cref="SyncMode.Notify"/>.</summary>
        public bool IsOutOfDate { get; private set; }

        /************************************************************************************************************************/

        private bool CheckIfOutOfDate()
        {
            if (LinkerWindow.Instance != null)
                LinkerWindow.Instance.Repaint();

            if (IsFile)
                return File.GetLastWriteTime(Source) != File.GetLastWriteTime(Destination);

            if (!Directory.Exists(Destination))
            {
                DebugLog("Destination doesn't exist");
                return true;
            }

            // Source Files.
            foreach (var file in SourceFiles)
            {
                if (IsFileOutOfDate(file))
                {
                    DebugLog("Source File out of date: " + file);
                    return true;
                }
            }

            // Source Directories.
            foreach (var directory in SourceDirectories)
            {
                if (IsDirectoryOutOfDate(directory))
                {
                    DebugLog("Source Directory out of date: " + directory);
                    return true;
                }
            }

            // Destination Files.
            foreach (var file in SourceFiles)
            {
                if (IsFileOutOfDate(SourceToDestination(file)))
                {
                    DebugLog("Destination File out of date: " + file);
                    return true;
                }
            }

            // Destination Directories.
            foreach (var directory in SourceDirectories)
            {
                if (IsDirectoryOutOfDate(SourceToDestination(directory)))
                {
                    DebugLog("Destination Directory out of date: " + directory);
                    return true;
                }
            }

            if (AreAnySourceItemsNew(Source))
                return true;

#if !LITE
            if (TwoWay && AreAnyDestinationItemsNew(Destination))
                return true;
#endif

            return false;
        }

        /************************************************************************************************************************/

        private bool IsFileOutOfDate(string path)
        {
            return !File.Exists(path) || IsItemOutOfDate(path);
        }

        private bool IsDirectoryOutOfDate(string path)
        {
            return !Directory.Exists(path) || IsItemOutOfDate(path);
        }

        private bool IsItemOutOfDate(string path)
        {
            // From the MSDNpage for File.GetLastWriteTime:
            // If the file described in the path parameter does not exist, this method returns
            // 12:00 midnight, January 1, 1601 A.D. (C.E.) Coordinated Universal Time (UTC), adjusted to local time.

            // ... WTF kind of default value is that?

            return File.GetLastWriteTime(path) > LastSync;
        }

        /************************************************************************************************************************/

        private bool AreAnySourceItemsNew(string directory)
        {
            string[] files = Directory.GetFiles(directory);
            for (int i = 0; i < files.Length; i++)
            {
                string file = files[i];
                if (!SourceFiles.Contains(file) && !IsExcluded(file))
                {
                    DebugLog("Source File is new: " + file);
                    return true;
                }
            }

            files = Directory.GetDirectories(directory);
            for (int i = 0; i < files.Length; i++)
            {
                directory = files[i];
                if (!IsExcluded(directory) && (!SourceDirectories.Contains(directory) || AreAnySourceItemsNew(directory)))
                {
                    DebugLog("Source Directory is new: " + directory);
                    return true;
                }
            }

            return false;
        }

        /************************************************************************************************************************/

        private bool AreAnyDestinationItemsNew(string directory)
        {
            string[] files = Directory.GetFiles(directory);
            for (int i = 0; i < files.Length; i++)
            {
                string soutrceFile = DestinationToSource(files[i]);
                if (!SourceFiles.Contains(soutrceFile) && !IsExcluded(soutrceFile))
                {
                    DebugLog("Destination File is new: " + files[i]);
                    return true;
                }
            }

            files = Directory.GetDirectories(directory);
            for (int i = 0; i < files.Length; i++)
            {
                directory = files[i];
                string sourceDirectory = DestinationToSource(directory);
                if (!IsExcluded(directory) && (!SourceDirectories.Contains(sourceDirectory) || AreAnyDestinationItemsNew(directory)))
                {
                    DebugLog("Destination Directory is new: " + directory);
                    return true;
                }
            }

            return false;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Exclusions
        /************************************************************************************************************************/

        public void AddExclusion(string subPath)
        {
            Exclusions.Add(subPath);

            subPath = Source + subPath;
            SourceFiles.Remove(subPath);
            SourceDirectories.Remove(subPath);

            if (!subPath.EndsWith(".meta"))
            {
                subPath += ".meta";
                if (File.Exists(subPath))
                    SourceFiles.Remove(subPath);
            }
        }

        /************************************************************************************************************************/

        public void GetExclusions(List<string> exclusions)
        {
            exclusions.Clear();
            exclusions.AddRange(Exclusions);
        }

        /************************************************************************************************************************/

        public bool AreExclusionListsIdentical(List<string> exclusions)
        {
            if (Exclusions.Count != exclusions.Count)
                return false;

            for (int i = 0; i < Exclusions.Count; i++)
            {
                if (Exclusions[i] != exclusions[i])
                    return false;
            }

            return true;
        }

        /************************************************************************************************************************/

        private bool IsExcluded(string sourcePath)
        {
            return IsExcluded(sourcePath, Source);
        }

        public bool IsExcluded(string path, string root)
        {
#if !LITE
            if (IsFile)
                return path != root;

            if (path.Length <= root.Length)
                return false;

            for (int i = 0; i < Exclusions.Count; i++)
            {
                string exclusion = Exclusions[i];
                if (path.Length >= exclusion.Length &&
                    string.Compare(path, root.Length, exclusion, 0, exclusion.Length) == 0)
                {
                    // The exact path is excluded.
                    if (path.Length == root.Length + exclusion.Length)
                        return true;

                    // The target of a meta file is excluded.
                    if (path.Length == root.Length + exclusion.Length + 5 && path.EndsWith(".meta"))
                        return true;

                    // The exclusion is a folder which contains the path.
                    if (path[root.Length + exclusion.Length] == Utils.Slash)
                        return true;
                }
            }
#endif

            return false;
        }

        /************************************************************************************************************************/

        private bool IsMetaWithoutTarget(string sourceFile)
        {
            if (sourceFile.EndsWith(".meta"))
            {
                sourceFile = sourceFile.Substring(0, sourceFile.Length - 5);
                return !File.Exists(sourceFile) && !Directory.Exists(sourceFile) && !IsExcluded(sourceFile);
            }
            else return false;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Save and Load
        /************************************************************************************************************************/

        public static readonly string FilePath = System.Environment.CurrentDirectory + "\\" + Utils.ProductName + ".txt";

        /************************************************************************************************************************/

        static Link()
        {
            if (!File.Exists(FilePath))
            {
                ProjectWindowOverlay.Enabled = true;
                return;
            }

            try
            {
                using (FileStream stream = new FileStream(FilePath, FileMode.Open))
                using (BinaryReader reader = new BinaryReader(stream))
                {
                    int linkCount = reader.ReadInt32();
                    while (linkCount-- > 0)
                    {
                        AllLinks.Add(new Link(reader));
                    }

                    ProjectWindowOverlay.Enabled = reader.ReadBoolean();
                }

                AskIfAutoSyncIsAllowed();
                AutoSyncAll();
            }
            catch (System.Exception ex)
            {
                Utils.LogException("failed to load file at " + FilePath + "\n", ex);
                AllLinks.Clear();
                ForceSave();
            }
        }

        /************************************************************************************************************************/

        private Link(BinaryReader reader)
        {
            Source = reader.ReadString();
            Destination = reader.ReadString();
            TwoWay = reader.ReadBoolean();
            Mode = (SyncMode)reader.ReadByte();
            LastSync = new System.DateTime(reader.ReadInt64());
            Hue = reader.ReadSingle();

#if LITE
            TwoWay = false;
            Mode = SyncMode.Manual;
#endif

            if (Source.Length > 0)
                IsFile = !Source.EndsWithSlash();

            ReadStringList(reader, Exclusions);
            ReadStringSet(reader, SourceDirectories);
            ReadStringSet(reader, SourceFiles);

            InitialiseWatcher();
        }

        private void ReadStringList(BinaryReader reader, List<string> list)
        {
            int count = reader.ReadInt32();
            while (count-- > 0)
                list.Add(reader.ReadString());
        }

        private void ReadStringSet(BinaryReader reader, HashSet<string> set)
        {
            int count = reader.ReadInt32();
            while (count-- > 0)
                set.Add(Source + reader.ReadString());
        }

        /************************************************************************************************************************/

        private static bool _NeedsToSave;

        public static void SaveAll()
        {
            if (_NeedsToSave)
                ForceSave();
        }

        public static void ForceSave()
        {
            Utils.DebugLog("Saving settings to " + FilePath);

            try
            {
                using (FileStream stream = new FileStream(FilePath, FileMode.Create))
                using (BinaryWriter writer = new BinaryWriter(stream))
                {
                    writer.Write(AllLinks.Count);
                    for (int i = 0; i < AllLinks.Count; i++)
                    {
                        AllLinks[i].Write(writer);
                    }

                    writer.Write(ProjectWindowOverlay.Enabled);
                }

                _NeedsToSave = false;
            }
            catch (System.Exception ex)
            {
                Utils.LogException("failed to save file at " + FilePath + "\n", ex);
            }
        }

        /************************************************************************************************************************/

        private void Write(BinaryWriter writer)
        {
            writer.Write(Source);
            writer.Write(Destination);
            writer.Write(TwoWay);
            writer.Write((byte)Mode);
            writer.Write(LastSync.Ticks);
            writer.Write(Hue);

            WriteStringList(writer, Exclusions);
            WritePathSet(writer, SourceDirectories);
            WritePathSet(writer, SourceFiles);
        }

        private void WriteStringList(BinaryWriter writer, List<string> list)
        {
            writer.Write(list.Count);
            for (int i = 0; i < list.Count; i++)
            {
                writer.Write(list[i]);
            }
        }

        private void WritePathSet(BinaryWriter writer, HashSet<string> set)
        {
            writer.Write(set.Count);
            foreach (var entry in set)
                WriteSubPath(writer, entry);
        }

        private void WriteSubPath(BinaryWriter writer, string path)
        {
            writer.Write(path.Substring(Source.Length, path.Length - Source.Length));
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Utils
        /************************************************************************************************************************/

        public bool ArePathsValid(bool logWarnings)
        {
            return IsValidSource(Source, logWarnings) && IsValidDestination(Destination, logWarnings);
        }

        public static bool IsValidSource(string source, bool logWarnings)
        {
            if (string.IsNullOrEmpty(source) ||
                (!Directory.Exists(source) && !File.Exists(source)))
                return false;

            if (System.Environment.CurrentDirectory.StartsWith(Utils.RelativeToAbsolute(source)))
            {
                if (logWarnings)
                    Debug.LogWarning("Invalid Source \"" + source + "\": Source must not be a parent directory of the current project.");
                return false;
            }

            if (Utils.IsInsideThisProject(source))
            {
                if (logWarnings)
                    Debug.LogWarning("Invalid Source \"" + source + "\": Source must be outside the current project.");
                return false;
            }

            return true;
        }

        public static bool IsValidDestination(string destination, bool logWarnings)
        {
            if (string.IsNullOrEmpty(destination))
                return false;

            if (!Utils.IsInsideThisProject(destination))
            {
                if (logWarnings)
                    Debug.LogWarning("Invalid Destination: \"" + destination + "\": Destination must be inside the current project.");
                return false;
            }

            return true;
        }

        /************************************************************************************************************************/

        public string SourceToDestination(string sourcePath)
        {
            return Utils.ConvertSubPath(sourcePath, Source, Destination);
        }

        public string DestinationToSource(string destinationPath)
        {
            return Utils.ConvertSubPath(destinationPath, Destination, Source);
        }

        /************************************************************************************************************************/

        public static void MatchDisplayOrder(List<LinkDisplay> displays)
        {
            AllLinks.Clear();
            for (int i = 0; i < displays.Count; i++)
            {
                Link link = displays[i].Target;
                if (link != null && link.ArePathsValid(false))
                    AllLinks.Add(link);
            }
            _NeedsToSave = true;
        }

        /************************************************************************************************************************/

        public static void GetContainingLink(ref string assetPath, out Link singleLink, out List<Link> multipleLinks)
        {
            singleLink = null;
            multipleLinks = null;

            assetPath = assetPath.NormalizeSlashes();

            for (int i = 0; i < AllLinks.Count; i++)
            {
                Link link = AllLinks[i];
                if (link.Contains(assetPath))
                {
                    if (singleLink == null)
                    {
                        singleLink = link;
                    }
                    else
                    {
                        if (multipleLinks == null)
                        {
                            multipleLinks = new List<Link>();
                            multipleLinks.Add(singleLink);
                        }

                        multipleLinks.Add(link);
                    }
                }
            }
        }

        public static Link GetContainingLink(ref string assetPath)
        {
            Link singleLink;
            List<Link> multipleLinks;
            GetContainingLink(ref assetPath, out singleLink, out multipleLinks);
            return singleLink;
        }

        /************************************************************************************************************************/

        public static Link GetContainingLink(Object asset, out string assetPath)
        {
            assetPath = AssetDatabase.GetAssetPath(asset);
            if (string.IsNullOrEmpty(assetPath))
                return null;
            else
                return GetContainingLink(ref assetPath);
        }

        /************************************************************************************************************************/

        private bool Contains(string path)
        {
            if (string.IsNullOrEmpty(Source) || string.IsNullOrEmpty(Destination))
                return false;

            if (IsFile)
                return path == Destination;

            if (!path.StartsWith(Destination))
            {
                // If the path is exactly 1 character shorter than the destination,
                // it might be the destination without the trailing slash.
                return (path.Length == Destination.Length - 1 &&
                    string.Compare(path, 0, Destination, 0, Destination.Length - 1) == 0);
            }

            if (!Directory.Exists(Source))
                return false;

            path = DestinationToSource(path);
            return SourceDirectories.Contains(path) || SourceFiles.Contains(path) || path == Source;
        }

        /************************************************************************************************************************/

        [System.Diagnostics.Conditional("DEBUG")]
        public void DebugLog(object message)
        {
            Debug.Log(string.Concat(Utils.LogPrefix + "Link ", GetColoredDescription(), ": " + message), GetContext());
        }

        /************************************************************************************************************************/

        private Object GetContext()
        {
            return AssetDatabase.LoadAssetAtPath<Object>(Destination.RemoveTrailingSlashes());
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}