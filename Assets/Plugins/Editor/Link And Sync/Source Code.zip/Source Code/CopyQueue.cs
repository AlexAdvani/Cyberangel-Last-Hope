﻿// Link & Sync // Copyright 2016 Kybernetik //

//#define SAFE_MODE

using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace LinkAndSync
{
    internal static class CopyQueue
    {
        /************************************************************************************************************************/

        private static readonly List<Item>
            Queue = new List<Item>(),
            SpareItems = new List<Item>();

        /************************************************************************************************************************/

        private sealed class Item
        {
            /************************************************************************************************************************/

            public string from;
            public string to;
            public System.DateTime dateModified;

            /************************************************************************************************************************/

            public void Copy(float progress)
            {
                if (from != null)
                {
                    Utils.DebugLog("Copying File from [" + from + "] to [" + to + "]");
                    if (Utils.IsReadyForProgress()) Utils.DisplayProgressBar("Copying: " + from, progress);
                    File.Copy(from, to, true);
                    File.SetLastWriteTime(to, dateModified);
                }
                else
                {
                    Utils.DebugLog("Creating Directory at [" + to + "]");
                    if (Utils.IsReadyForProgress()) Utils.DisplayProgressBar("Creating: " + to, progress);
                    Directory.CreateDirectory(to);
                    Directory.SetLastWriteTime(to, dateModified);
                }
            }

            /************************************************************************************************************************/

            public override string ToString()
            {
                return from + " -> " + to;
            }

            /************************************************************************************************************************/
        }

        /************************************************************************************************************************/

        private static Item GetSpareItem()
        {
            if (SpareItems.Count == 0)
            {
                return new Item();
            }
            else
            {
                Item item = SpareItems[SpareItems.Count - 1];
                SpareItems.RemoveAt(SpareItems.Count - 1);
                return item;
            }
        }

        /************************************************************************************************************************/

        public static void AddFile(string from, string to, System.DateTime dateModified)
        {
            Item item = GetSpareItem();

            item.from = from;
            item.to = to;
            item.dateModified = dateModified;

            Queue.Add(item);
        }

        public static void AddFile(string from, string to)
        {
            AssertString(from);
            AssertString(to);

            AddFile(from, to, Directory.GetLastWriteTime(from));
        }

        public static void AddDirectory(string path, System.DateTime dateModified)
        {
            AssertString(path);

            AddFile(null, path, dateModified);
        }

        public static void AddDirectory(string path)
        {
            AddDirectory(path, System.DateTime.Now);
        }

        /************************************************************************************************************************/

        public static void AddDirectoryRecursive(string from, string to, bool fromSource, HashSet<string> sourceFiles, HashSet<string> sourceDirectories)
        {
            AssertString(from);
            AssertString(to);

            AddDirectory(to);

            string[] files = Directory.GetFiles(from);
            for (int i = 0; i < files.Length; i++)
            {
                string file = files[i];
                string fileTo = Utils.ConvertSubPath(file, from, to);
                AddFile(file, fileTo);
                sourceFiles.Add(fromSource ? file : fileTo);
            }

            files = Directory.GetDirectories(from);
            for (int i = 0; i < files.Length; i++)
            {
                string directory = files[i];
                string directoryTo = Utils.ConvertSubPath(directory, from, to);
                AddDirectoryRecursive(directory, directoryTo, fromSource, sourceFiles, sourceDirectories);
                sourceDirectories.Add(fromSource ? directory : directoryTo);
            }
        }

        /************************************************************************************************************************/

        [System.Diagnostics.Conditional("SAFE_MODE")]
        private static void AssertString(string value)
        {
            if (string.IsNullOrEmpty(value))
                Debug.LogError(Utils.LogPrefix + nameof(CopyQueue) + " Error: path is null or empty.");
        }

        /************************************************************************************************************************/

        public static bool ExecuteQueue()
        {
            if (Queue.Count == 0)
            {
                Utils.DebugLog("No sync operations were added");
                Utils.ClearProgress();
                AssetDatabase.Refresh();
                return false;
            }

            AssetDatabase.StartAssetEditing();

            float inverseCount = 1f / Queue.Count;
            int i = 0;

            CopyingLoop:
            try
            {
                for (; i < Queue.Count; i++)
                    Queue[i].Copy(i * inverseCount);
            }
            catch (System.Exception ex)
            {
                Utils.LogException(nameof(CopyQueue) + " Error: " + Queue[i], ex);
                i++;
                if (i < Queue.Count)
                    goto CopyingLoop;
            }

            Utils.DebugLog("Completed " + Queue.Count + " sync operations");
            Clear();

            AssetDatabase.StopAssetEditing();
            AssetDatabase.Refresh();

            Utils.ClearProgress();
            ProjectWindowOverlay.ClearCache();

            return true;
        }

        /************************************************************************************************************************/

        public static void Clear()
        {
            SpareItems.AddRange(Queue);
            Queue.Clear();
        }

        public static void AssertEmpty()
        {
            if (Queue.Count != 0)
            {
                Debug.LogError(Utils.LogPrefix + nameof(CopyQueue) + " Error: the queue should have been cleared by an earlier operation.");
                Clear();
            }
        }

        /************************************************************************************************************************/

        public static void LogQueue()
        {
            StringBuilder text = new StringBuilder();
            text.Append(Utils.LogPrefix + nameof(CopyQueue) + ": ").Append(Queue.Count);

            for (int i = 0; i < Queue.Count; i++)
            {
                Item item = Queue[i];
                text.AppendLine().Append(item.from).Append(" -> ").Append(item.to).Append(" : ").Append(item.dateModified);
            }

            Debug.Log(text);
        }

        /************************************************************************************************************************/
    }
}
