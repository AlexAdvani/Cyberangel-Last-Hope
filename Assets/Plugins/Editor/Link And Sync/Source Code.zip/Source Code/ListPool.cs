﻿// Kybernetik // Copyright 2016 Kybernetik //

using System.Collections.Generic;
using UnityEngine;

namespace LinkAndSync
{
    internal static partial class Utils
    {
        /************************************************************************************************************************/

        private static class ListPool<T>
        {
            // Not a Stack because it would create an unnecessary dependency on System.dll.
            public static readonly List<List<T>> Lists = new List<List<T>>();

            public static List<T> Pop()
            {
                if (Lists.Count > 0)
                {
                    List<T> list = Lists[Lists.Count - 1];
                    if (list.Count != 0)
                        Debug.LogError("Utils.GetList returned a non-empty list. You should never use a list after releasing it.");
                    Lists.RemoveAt(Lists.Count - 1);
                    return list;
                }
                else return new List<T>();
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns an available list from the pool or creates a new one if there are none.
        /// </summary>
        public static List<T> GetList<T>()
        {
            return ListPool<T>.Pop();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Clears a list and puts it into the pool to be available for future use.
        /// </summary>
        public static void Release<T>(this List<T> list)
        {
            list.Clear();
            ListPool<T>.Lists.Add(list);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Removes all lists from the pool so they can be garbage collected (assuming they aren't still referenced elsewhere).
        /// </summary>
        public static void ClearListPool<T>()
        {
            ListPool<T>.Lists.Clear();
        }

        /************************************************************************************************************************/
    }
}