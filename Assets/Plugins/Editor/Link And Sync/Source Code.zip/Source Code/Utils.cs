﻿// Link & Sync // Copyright 2016 Kybernetik //

using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace LinkAndSync
{
    internal static partial class Utils
    {
        /************************************************************************************************************************/

        public const string ProductName = "Link & Sync";
        public const string LogPrefix = "<B>Link & Sync</B>: ";

        /************************************************************************************************************************/

        public static bool DeleteIfEmpty(string directory)
        {
            // If it has any sub-directories, don't delete it.
            if (!Directory.Exists(directory) || Directory.GetDirectories(directory).Length > 0)
                return false;

            // If it has any non-meta files, don't delete it.
            string[] files = Directory.GetFiles(directory);
            for (int i = 0; i < files.Length; i++)
            {
                if (!files[i].EndsWith(".meta"))
                    return false;
            }

            // Otherwise delete all the files then the directory itself.

            if (Utils.IsReadyForProgress()) Utils.DisplayProgressBar("Deleting: " + directory, 0);

            for (int i = 0; i < files.Length; i++)
                File.Delete(files[i]);

            Directory.Delete(directory);
            return true;
        }

        /************************************************************************************************************************/

        public static void SortDeepestFirst(List<string> paths)
        {
            // No need to compare the full strings when all we need is for deeper folders to be deleted first
            // so they don't prevent their parents from being deleted if they are empty.
            paths.Sort((a, b) => b.Length.CompareTo(a.Length));
        }

        /************************************************************************************************************************/

        private static readonly string NormalizedDataPath = Application.dataPath.NormalizeSlashes();

        public static bool IsInsideThisProject(string path)
        {
            if (path.StartsWith(@"..\"))
                return false;

            if (Path.IsPathRooted(path))
                return path.StartsWith(NormalizedDataPath);

            return true;
        }

        /************************************************************************************************************************/

        public static void LogException(string message, System.Exception ex)
        {
            Debug.LogError(LogPrefix + "Exception: " + message + ex);
        }

        /************************************************************************************************************************/

        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugLog(object message)
        {
            Debug.Log(LogPrefix + message);
        }

        /************************************************************************************************************************/

        public const char Slash = '\\';

        /// <summary>Convert all forward slashes back slashes.</summary>
        public static string NormalizeSlashes(this string str)
        {
            return str.Replace('/', Slash);
        }

        public static string EndWithSlash(this string str)
        {
            if (str.Length > 0 && !str.EndsWithSlash())
                return str + Slash;
            else
                return str;
        }

        public static string RemoveTrailingSlashes(this string str)
        {
            int end = str.Length - 1;
            while (str[end] == Slash)
            {
                end--;
            }

            return str.Substring(0, end + 1);
        }

        public static bool EndsWithSlash(this string str)
        {
            return str[str.Length - 1] == Slash;
        }

        /************************************************************************************************************************/

        /// <summary>Returns a string containing the value of each element of the given collection.</summary>
        public static string DeepToString(this IEnumerable collection, string separator)
        {
            if (collection == null) return "null";

            StringBuilder text = new StringBuilder();

            text.Append("[]");
            int countIndex = text.Length - 1;

            int i = 0;
            foreach (object item in collection)
            {
                text.Append(separator);
                text.Append('[');
                text.Append(i);
                text.Append("] = ");
                text.Append(item);

                i++;
            }

            text.Insert(countIndex, i);

            return text.ToString();
        }

        /// <summary>Returns a string containing the value of each element of the given collection (each on a new line).</summary>
        public static string DeepToString(this IEnumerable collection)
        {
            return collection.DeepToString(System.Environment.NewLine);
        }

        /************************************************************************************************************************/

        public static Color HSBtoRGB(float hue, float saturation, float brightness)
        {
            hue %= 1;
            if (hue < 0) hue += 1;
            int index = (int)(hue * 6);

            float fraction = hue * 6 - index;

            float p = brightness * (1 - saturation);
            float q = brightness * (1 - fraction * saturation);
            float t = brightness * (1 - (1 - fraction) * saturation);

            switch (index)
            {
                case 0:
                    return new Color(brightness, t, p);
                case 1:
                    return new Color(q, brightness, p);
                case 2:
                    return new Color(p, brightness, t);
                case 3:
                    return new Color(p, q, brightness);
                case 4:
                    return new Color(t, p, brightness);
                case 5:
                    return new Color(brightness, p, q);
                default:
                    Debug.LogError("index = " + index + " is invalid");
                    return Color.white;
            }
        }

        /************************************************************************************************************************/

        public static void AppendBoldColored(StringBuilder text, Color color, string str)
        {
            text.Append("<B><color=#");
            text.AppendFormat("{0:X2}", (int)(color.r * 255));
            text.AppendFormat("{0:X2}", (int)(color.g * 255));
            text.AppendFormat("{0:X2}", (int)(color.b * 255));
            text.Append('>');
            text.Append(str);
            text.Append("</color></B>");
        }

        public static string TagAsBoldColored(string str, Color color)
        {
            StringBuilder text = new StringBuilder();
            AppendBoldColored(text, color, str);
            return text.ToString();
        }

        /************************************************************************************************************************/

        public static bool BrowseForRelativeFolder(string name, ref string path)
        {
            string folder = EditorUtility.OpenFolderPanel("Select " + name + " Folder", path, "");
            if (!string.IsNullOrEmpty(folder))
            {
                path = Utils.AbsoluteToRelative(folder);
                return true;
            }
            else return false;
        }

        public static bool BrowseToCreateRelativeFolder(string name, ref string path)
        {
            string folder = EditorUtility.SaveFolderPanel("Select " + name + " Folder", path, "");
            if (!string.IsNullOrEmpty(folder))
            {
                path = Utils.AbsoluteToRelative(folder);
                return true;
            }
            else return false;
        }

        public static bool BrowseForFile(string title, ref string path)
        {
            string folder = EditorUtility.OpenFilePanel(title, RelativeToAbsolute(path), "");
            if (!string.IsNullOrEmpty(folder))
            {
                path = Utils.AbsoluteToRelative(folder);
                return true;
            }
            else return false;
        }

        /************************************************************************************************************************/

        public static bool WasDirectoryModifiedAfter(string path, System.DateTime date)
        {
            if (Directory.GetLastWriteTime(path) > date)
                return true;

            string[] files = Directory.GetFiles(path);
            for (int i = 0; i < files.Length; i++)
            {
                if (File.GetLastWriteTime(files[i]) > date)
                    return true;
            }

            files = Directory.GetDirectories(path);
            for (int i = 0; i < files.Length; i++)
            {
                if (WasDirectoryModifiedAfter(files[i], date))
                    return true;
            }

            return false;
        }

        /************************************************************************************************************************/
        #region Progress Bar
        /************************************************************************************************************************/

        private static double _PreviousProgressTime;

        public static void ClearProgress()
        {
            _PreviousProgressTime = 0;
            EditorUtility.ClearProgressBar();
        }

        public static bool IsShowingProgress()
        {
            return _PreviousProgressTime != 0;
        }

        public static bool IsReadyForProgress()
        {
            return _PreviousProgressTime + 0.1 < EditorApplication.timeSinceStartup;
        }

        public static void DisplayProgressBar(string message, float progress)
        {
            EditorUtility.DisplayProgressBar(ProductName, message, progress);
            _PreviousProgressTime = EditorApplication.timeSinceStartup;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Path Conversion
        /************************************************************************************************************************/

        private static readonly Dictionary<string, string>
            RelativePaths = new Dictionary<string, string>(),
            AbsolutePaths = new Dictionary<string, string>();

        /************************************************************************************************************************/

        public static string AbsoluteToRelative(string path)
        {
            if (string.IsNullOrEmpty(path))
                return "";

            string relativePath;
            if (RelativePaths.TryGetValue(path, out relativePath))
                return relativePath;

            if (!Path.IsPathRooted(path))
            {
                RelativePaths.Add(path, path);
                return path;
            }

            string currentDirectory = System.Environment.CurrentDirectory;
            relativePath = path.NormalizeSlashes();

            // Trim any identical folders from the start.
            int index = 0;
            while (true)
            {
                int slash = relativePath.IndexOf(Slash, index);
                if (slash < 0) slash = relativePath.Length;

                if (string.Compare(relativePath, index, currentDirectory, index, slash - index) != 0)
                {
                    if (index == 0)
                        return relativePath;

                    relativePath = relativePath.Substring(index, relativePath.Length - index);
                    break;
                }
                else
                {
                    index = slash + 1;
                    if (index >= relativePath.Length)
                    {
                        Debug.LogWarning("Invalid path: " + relativePath + " is a direct parent of the current project.");
                        return "";
                    }
                    else if (index >= currentDirectory.Length)
                    {
                        return relativePath.Substring(index, relativePath.Length - index);
                    }
                }
            }

            // Prefix the path with ..\ for each folder level it needs to go up.
            do
            {
                relativePath = "..\\" + relativePath;
                index = currentDirectory.IndexOf(Utils.Slash, index + 1);
            }
            while (index >= 0 && index < currentDirectory.Length);

            RelativePaths.Add(path, relativePath);
            return relativePath;

            // Unit Tests.
            //Debug.Log(Link.AbsoluteToRelative(@"C:\Users\Kailas\Desktop"));
            //Debug.Log(Link.AbsoluteToRelative(@"C:\Users\Kailas\Desktop\Link and Sync"));
            //Debug.Log(Link.AbsoluteToRelative(@"C:\Users\Kailas\Desktop\Link and Sync\Assets"));
            //Debug.Log(Link.AbsoluteToRelative(@"C:\Users\Kailas\Desktop\Link and Sync\Assets\"));
            //Debug.Log(Link.AbsoluteToRelative(@"C:\Users\Kailas\Desktop\Test Resources\Cards"));
            //Debug.Log(Link.AbsoluteToRelative(@"C:\Users\Somewhere\Else"));
            //Debug.Log(Link.AbsoluteToRelative(@"A:\Another\Drive"));
        }

        /************************************************************************************************************************/

        public static string RelativeToAbsolute(string path)
        {
            return Path.GetFullPath(path);
        }

        /************************************************************************************************************************/

        public static string ToggleRelativity(string path)
        {
            if (Path.IsPathRooted(path))
                return AbsoluteToRelative(path);
            else
                return RelativeToAbsolute(path);
        }

        /************************************************************************************************************************/

        public static string ConvertSubPath(string path, string fromRoot, string toRoot)
        {
            return toRoot + path.Substring(fromRoot.Length, path.Length - fromRoot.Length);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Menu Items
        /************************************************************************************************************************/

        [MenuItem("Assets/Link and Sync/Sync Selected Links")]
        private static void Sync()
        {
            List<Link> links = GatherLinksInSelection();

            for (int i = 0; i < links.Count; i++)
                links[i].Sync();

            Link.SaveAll();
        }

        /************************************************************************************************************************/

        [MenuItem("Assets/Link and Sync/Sync All Links")]
        private static void SyncAll()
        {
            Link.SyncAll();
        }

        /************************************************************************************************************************/
#if !LITE
        /************************************************************************************************************************/

        [MenuItem("Assets/Link and Sync/Exclude Selection from Link")]
        private static void ExcludeFromLink()
        {
            var selection = Selection.objects;
            for (int i = 0; i < selection.Length; i++)
            {
                string path;
                Link link = Link.GetContainingLink(selection[i], out path);

                if (link != null && link.Destination != path)
                {
                    path = path.Substring(link.Destination.Length, path.Length - link.Destination.Length);
                    link.AddExclusion(path);
                    LinkerWindow.UpdateExclusionDisplay(link);
                }
            }

            Link.ForceSave();
            ProjectWindowOverlay.ClearCache();
        }

        [MenuItem("Assets/Link and Sync/Exclude Selection from Link", validate = true)]
        private static bool ValidateExcludeFromLink()
        {
            var selection = Selection.objects;
            for (int i = 0; i < selection.Length; i++)
            {
                string path;
                Link link = Link.GetContainingLink(selection[i], out path);

                if (link != null && link.Destination.RemoveTrailingSlashes() != path)
                    return true;
            }

            return false;
        }
        
        /************************************************************************************************************************/

        [MenuItem("Assets/Link and Sync/Two Way Sync Selected Links")]
        private static void TwoWaySync()
        {
            CopyQueue.AssertEmpty();

            foreach (var link in GatherSelectedLinks())
            {
                bool previousValue = link.TwoWay;
                link.TwoWay = true;
                link.Sync();
                link.TwoWay = previousValue;
            }

            CopyQueue.ExecuteQueue();
            Link.SaveAll();
        }

        /************************************************************************************************************************/

        private static HashSet<Link> GatherSelectedLinks()
        {
            HashSet<Link> links = new HashSet<Link>();
            HashSet<string> pathsChecked = new HashSet<string>();

            var selection = Selection.objects;
            for (int i = 0; i < selection.Length; i++)
            {
                string path = AssetDatabase.GetAssetPath(selection[i]);
                if (string.IsNullOrEmpty(path) ||
                    pathsChecked.Contains(path))
                    continue;

                if (Directory.Exists(path))
                {
                    GatherLinksInDirectory(path, links, pathsChecked);
                }
                else
                {
                    pathsChecked.Add(path);
                    Link link = Link.GetContainingLink(ref path);
                    if (link != null)
                        links.Add(link);
                }
            }

            return links;
        }

        private static void GatherLinksInDirectory(string directory, HashSet<Link> links, HashSet<string> pathsChecked)
        {
            if (pathsChecked.Contains(directory))
                return;
            else
                pathsChecked.Add(directory);

            Link link = Link.GetContainingLink(ref directory);
            if (link != null)
            {
                links.Add(link);
                return;
            }

            string[] files = Directory.GetFiles(directory);
            for (int i = 0; i < files.Length; i++)
            {
                string file = files[i];

                if (pathsChecked.Contains(file))
                    return;
                else
                    pathsChecked.Add(file);

                link = Link.GetContainingLink(ref file);
                if (link != null)
                {
                    links.Add(link);
                }
            }

            files = Directory.GetDirectories(directory);
            for (int i = 0; i < files.Length; i++)
            {
                GatherLinksInDirectory(files[i], links, pathsChecked);
            }
        }

        /************************************************************************************************************************/

        [MenuItem("Assets/Link and Sync/Two Way Sync Selected Links", validate = true)]
#endif

        [MenuItem("Assets/Link and Sync/Sync Selected Links", validate = true)]
        private static bool IsAnyChildOfSelectionLinked()
        {
            var selection = Selection.objects;
            for (int i = 0; i < selection.Length; i++)
            {
                string path = AssetDatabase.GetAssetPath(selection[i]);
                if (string.IsNullOrEmpty(path))
                    continue;

                if (Directory.Exists(path))
                {
                    if (IsAnyChildLinked(path))
                        return true;
                }
                else
                {
                    if (Link.GetContainingLink(ref path) != null)
                        return true;
                }
            }

            return false;
        }

        private static bool IsAnyChildLinked(string directory)
        {
            if (Link.GetContainingLink(ref directory) != null)
                return true;

            string[] files = Directory.GetFiles(directory);
            for (int i = 0; i < files.Length; i++)
            {
                string file = files[i];
                if (Link.GetContainingLink(ref file) != null)
                    return true;
            }

            files = Directory.GetDirectories(directory);
            for (int i = 0; i < files.Length; i++)
            {
                if (IsAnyChildLinked(files[i]))
                    return true;
            }

            return false;
        }

        /************************************************************************************************************************/

        private static List<Link> GatherLinksInSelection()
        {
            List<Link> links = new List<Link>();

            var selection = Selection.objects;
            for (int i = 0; i < selection.Length; i++)
            {
                string path = AssetDatabase.GetAssetPath(selection[i]);
                if (string.IsNullOrEmpty(path))
                    continue;

                if (Directory.Exists(path))
                {
                    GatherLinksRecursive(path, links);
                }
                else
                {
                    Link link = Link.GetContainingLink(ref path);
                    if (link != null && !links.Contains(link))
                    {
                        links.Add(link);
                    }
                }
            }

            return links;
        }

        private static void GatherLinksRecursive(string directory, List<Link> links)
        {
            Link link = Link.GetContainingLink(ref directory);
            if (link != null && !links.Contains(link))
            {
                links.Add(link);
                return;
            }

            string[] files = Directory.GetFiles(directory);
            for (int i = 0; i < files.Length; i++)
            {
                string file = files[i];
                link = Link.GetContainingLink(ref file);
                if (link != null && !links.Contains(link))
                {
                    links.Add(link);
                }
            }

            files = Directory.GetDirectories(directory);
            for (int i = 0; i < files.Length; i++)
            {
                GatherLinksRecursive(files[i], links);
            }
        }

        /************************************************************************************************************************/

        [MenuItem("Assets/Link and Sync/Create Link Here")]
        private static void CreateLinkHere()
        {
            string path = AssetDatabase.GetAssetPath(Selection.activeObject);
            // We already know it's an asset from ValidateCreateLinkHere.

            LinkerWindow.OpenWindow();
            LinkerWindow.AddLink();
            LinkerWindow.LinkDisplays[LinkerWindow.LinkDisplays.Count - 1].DestinationPath = path.NormalizeSlashes();
        }

        [MenuItem("Assets/Link and Sync/Create Link Here", validate = true)]
        private static bool ValidateCreateLinkHere()
        {
            if (Selection.objects.Length != 1)
                return false;

            string path = AssetDatabase.GetAssetPath(Selection.activeObject);
            if (string.IsNullOrEmpty(path))
                return false;
            
            Link link;
            List<Link> links;
            Link.GetContainingLink(ref path, out link, out links);

            return link == null && links == null;
        }

        /************************************************************************************************************************/
#if LITE
        public const string LinkAndSyncProURL = "http://u3d.as/Bio";

        [MenuItem("Assets/Link and Sync/Purchase Link and Sync Pro")]
        private static void OpenLinkAndSyncProURL()
        {
            UnityEditorInternal.AssetStore.Open("content/72872");
        }
#endif
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}