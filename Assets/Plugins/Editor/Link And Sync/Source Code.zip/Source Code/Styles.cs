﻿// Link & Sync // Copyright 2016 Kybernetik //

using UnityEditor;
using UnityEngine;

namespace LinkAndSync
{
    internal static class Styles
    {
        /************************************************************************************************************************/

        public static readonly GUIStyle TextField, TextFieldError, LargeButton, LargeBoldButton, BoldButton, RightLabel, FooterBackground;

        /************************************************************************************************************************/

        static Styles()
        {
            TextField = new GUIStyle(GUI.skin.textField);
            TextField.contentOffset = new Vector2(0, 3);
            
            Color color = new Color(0.75f, 0, 0);
            TextFieldError = new GUIStyle(TextField);
            TextFieldError.normal.textColor = color;
            TextFieldError.active.textColor = color;
            TextFieldError.focused.textColor = color;

            LargeButton = new GUIStyle(GUI.skin.button);
            LargeButton.fontSize = 16;

            LargeBoldButton = new GUIStyle(LargeButton);
            LargeBoldButton.fontStyle = FontStyle.Bold;

            BoldButton = new GUIStyle(GUI.skin.button);
            BoldButton.fontStyle = FontStyle.Bold;

            RightLabel = new GUIStyle(GUI.skin.label);
            RightLabel.alignment = TextAnchor.MiddleRight;

            FooterBackground = new GUIStyle("RL Footer");
            FooterBackground.fixedHeight = 0;
        }

        /************************************************************************************************************************/
    }
}