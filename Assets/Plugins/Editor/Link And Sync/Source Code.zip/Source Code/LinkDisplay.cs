﻿// Link & Sync // Copyright 2016 Kybernetik //

using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;

namespace LinkAndSync
{
    internal sealed class LinkDisplay
    {
        /************************************************************************************************************************/

        public const float
            DisplayHeight = RowHeight * 2,
            ScrollBarWidth = 16;
        private const float
            RowHeight = 20,
            OpenFolderButtonWidth = 75,
            BrowseButtonWidth = 25,
            EndArea = 85 + SyncButtonWidth,
            SyncButtonWidth = 55,
            FileButtonWidth = 34,
            FolderButtonWidth = 50,
            RemoveButtonWidth = 20,
            ColorSliderHeight = 18;

        private static readonly GUIContent[] SyncModes =
        {
            new GUIContent("Manual", "Manual Mode: Only sync changes when the Sync button is clicked."),
            new GUIContent("Auto", "Auto Mode: Automatically sync changes whenever they are detected."),
            new GUIContent("Notify", "Notify Mode: Log a message when a change is detected."),
        };

        private static readonly GUIContent
            OpenSourceButton = new GUIContent("Source"),
            OpenDestinationButton = new GUIContent("Destination"),
            OpenExclusionButton = new GUIContent("Exclusion"),
            SourceBrowseButton = new GUIContent("...",
                "Browse for a source folder outside the project\nRight Click to convert the path between Relative and Absolute"),
            DestinationBrowseButton = new GUIContent("...", "Browse for a destination folder inside the project"),
            OneWayButton = new GUIContent("One", "One Way Link: this link will import changes from the source, but it will not export local changes back to the source"),
            TwoWayButton = new GUIContent("Two", "Two Way Link: this link will synchronise changes between the source and destination whenever either of them is modified"),
            FileExclusionBrowseButton = new GUIContent("File", "Browse for a file to exclude from the link"),
            FolderExclusionBrowseButton = new GUIContent("Folder", "Browse for a folder to exclude from the link"),
            SyncButton = new GUIContent("Sync", "Synchronise this Link\nRight Click to do a Full Reimport\nMiddle Click to revert changes");

        /************************************************************************************************************************/

        public Link Target { get; private set; }
        private readonly GUIContent
            Source = new GUIContent(),
            Destination = new GUIContent();
        private bool _TwoWay;
        private SyncMode _Mode;
        private float _Hue;
        public Color Color { get; private set; }
        private readonly List<string> _Exclusions = new List<string>();
        public bool IsDirty { get; private set; }

        public static LinkDisplay CurrentlyManaging { get; private set; }

        private static float _ScrollPosition;

        /************************************************************************************************************************/

        public string SourcePath { get { return Source.text; } }

        public string DestinationPath
        {
            get { return Destination.text; }
            set { Destination.text = value; }
        }

        /************************************************************************************************************************/

        public LinkDisplay()
        {
            // Pick a color as far away from the existing colors as possible.
            if (LinkerWindow.LinkDisplays.Count == 0)
            {
                _Hue = Random.Range(0f, 1f);
            }
            else if (LinkerWindow.LinkDisplays.Count == 1)
            {
                _Hue = (LinkerWindow.LinkDisplays[0]._Hue + 0.5f) % 1;
            }
            else
            {
                float[] hues = new float[LinkerWindow.LinkDisplays.Count];
                for (int i = 0; i < LinkerWindow.LinkDisplays.Count; i++)
                {
                    hues[i] = LinkerWindow.LinkDisplays[i]._Hue;
                }
                System.Array.Sort(hues);

                int index = 0;
                float largestDifference = 0;
                float previousHue = hues[hues.Length - 1] - 1;
                float hue;
                for (int i = 0; i < hues.Length; i++)
                {
                    hue = hues[i];
                    float difference = hue - previousHue;

                    if (difference > largestDifference)
                    {
                        largestDifference = difference;
                        index = i;
                    }

                    previousHue = hue;
                }

                previousHue = hues[index > 0 ? index - 1 : hues.Length - 1];
                hue = hues[index];
                if (previousHue < hue)
                    _Hue = (previousHue + hue) * 0.5f;
                else
                    _Hue = (previousHue - 1 + hue) * 0.5f + 1;
            }

            CalculateColor();
            IsDirty = true;
        }

        public LinkDisplay(Link link)
        {
            Target = link;
            Source.text = link.Source;
            Destination.text = link.Destination;
            _TwoWay = link.TwoWay;
            _Mode = link.Mode;
            _Hue = link.Hue;
            CalculateColor();
            GetExclusionsFromTarget();
        }

        /************************************************************************************************************************/

        private void CalculateColor()
        {
            Color = Utils.HSBtoRGB(_Hue, 0.5f, 1);
        }

        /************************************************************************************************************************/

        public void GetExclusionsFromTarget()
        {
            Target.GetExclusions(_Exclusions);
        }

        /************************************************************************************************************************/

        public void Draw(Rect rect)
        {
            EditorGUI.BeginChangeCheck();

            bool isValidSource = Link.IsValidSource(Source.text, false);
            bool isValidDestination = Link.IsValidDestination(Destination.text, false);

            // Source.
            rect.xMax -= EndArea - 3;
            rect.height = RowHeight;
            DrawPathField(rect, OpenSourceButton, Source, isValidSource, true);

            // Destination.
            rect.yMin = rect.yMax; rect.height = RowHeight;
            DrawPathField(rect, OpenDestinationButton, Destination, isValidDestination, false);

            // Mode.
            rect.xMin = rect.xMax; rect.width = EndArea - SyncButtonWidth;
            rect.yMin -= RowHeight; rect.height = RowHeight;
            DrawMode(rect);

            // Manage.
            rect.yMin += RowHeight; rect.height = RowHeight;
            DrawManageButton(rect);

            // Sync.
            rect.yMin -= RowHeight; rect.height = DisplayHeight;
            rect.xMin = rect.xMax; rect.width = SyncButtonWidth;
            GUI.enabled = isValidSource && isValidDestination && !EditorApplication.isCompiling;
            DrawSyncButton(rect);
            GUI.enabled = true;

            if (EditorGUI.EndChangeCheck())
                CheckIfDirty();
        }

        /************************************************************************************************************************/

        private void CheckIfDirty()
        {
            IsDirty =
                Target == null ||
                Target.IsOutOfDate ||
                _TwoWay != Target.TwoWay ||
                _Mode != Target.Mode ||
                _Hue != Target.Hue ||
                Source.text != Target.Source ||
                Destination.text != Target.Destination ||
                !Target.AreExclusionListsIdentical(_Exclusions);
        }

        /************************************************************************************************************************/

        private void DrawPathField(Rect rect, GUIContent name, GUIContent path, bool isValid, bool isSource)
        {
            float fieldWidth = rect.width - 100;

            // Open Folder Button.
            rect.width = OpenFolderButtonWidth;
            string reveal;
            if (string.IsNullOrEmpty(path.text))
            {
                reveal = null;
                GUI.enabled = false;
            }
            else if (File.Exists(path.text) || Directory.Exists(path.text))
            {
                reveal = path.text;
            }
            else
            {
                reveal = Path.GetDirectoryName(path.text);
                if (string.IsNullOrEmpty(reveal))
                    GUI.enabled = false;
            }

            if (GUI.Button(rect, name))
            {
                GUIUtility.keyboardControl = 0;
                EditorUtility.RevealInFinder(reveal);
            }
            GUI.enabled = true;

            EditorGUI.BeginChangeCheck();

            // Text Field.
            rect.xMin = rect.xMax; rect.width = fieldWidth;
            string newPath = EditorGUI.TextField(rect, path.text, isValid ? Styles.TextField : Styles.TextFieldError);
            if (path.text != newPath)
            {
                path.text = newPath;
                if (!isSource)
                    WarnAboutSharedDestinations();
            }

            // Drag and Drop
            path.text = CheckDragAndDrop(rect, isSource, path.text);

            // Browse Button.
            rect.xMin = rect.xMax; rect.width = BrowseButtonWidth;
            if (GUI.Button(rect, isSource ? SourceBrowseButton : DestinationBrowseButton))
            {
                if (isSource)
                {
                    if (Event.current.button != 1)
                    {
                        // Browse for a folder.
                        string folder = path.text;
                        if (Utils.BrowseForRelativeFolder(name.text, ref folder))
                        {
                            path.text = folder;
                            TryGuessDestination(folder);
                        }
                    }
                    else
                    {
                        path.text = Utils.ToggleRelativity(path.text);
                    }
                }
                else
                {
                    string folder = path.text;
                    Utils.BrowseToCreateRelativeFolder(name.text, ref folder);
                    path.text = folder;
                }

                GUIUtility.keyboardControl = 0;
            }

            if (EditorGUI.EndChangeCheck() && !isSource)
                WarnAboutSharedDestinations();
        }

        /************************************************************************************************************************/

        private string CheckDragAndDrop(Rect rect, bool isSource, string path)
        {
            switch (Event.current.type)
            {
                case EventType.DragUpdated:
                case EventType.MouseDrag:
                case EventType.DragPerform:
                    break;
                default:
                    return path;
            }

            if (DragAndDrop.paths.Length != 1 ||
                !rect.Contains(Event.current.mousePosition))
                return path;

            string draggedPath = DragAndDrop.paths[0];

            if (isSource == Utils.IsInsideThisProject(draggedPath))
                return path;

            if (Event.current.type != EventType.DragPerform)
                DragAndDrop.visualMode = DragAndDropVisualMode.Link;
            else
            {
                path = Utils.AbsoluteToRelative(draggedPath);
                if (isSource)
                    TryGuessDestination(path);
            }

            return path;
        }

        /************************************************************************************************************************/

        private void TryGuessDestination(string source)
        {
            // If a source was picked with no destination, try to guess the destination.

            if (!string.IsNullOrEmpty(Destination.text))
                return;

            int index = source.IndexOf(@"\Assets\");
            if (index >= 0)
            {
                index++;
                Destination.text = source.Substring(index, source.Length - index);
            }
            else
            {
                index = 0;
                while (index < source.Length - 3 && source[index] == '.' && source[index + 1] == '.' && source[index + 2] == Utils.Slash)
                {
                    index += 3;
                }

                Destination.text = @"Assets\" + source.Substring(index, source.Length - index);
            }
        }

        /************************************************************************************************************************/

        private static void WarnAboutSharedDestinations()
        {
            for (int i = 0; i < LinkerWindow.LinkDisplays.Count; i++)
            {
                LinkDisplay displayI = LinkerWindow.LinkDisplays[i];

                for (int j = i + 1; j < LinkerWindow.LinkDisplays.Count; j++)
                {
                    LinkDisplay displayJ = LinkerWindow.LinkDisplays[j];

                    if (displayI.DestinationPath == displayJ.DestinationPath)
                    {
                        Debug.LogWarning(Utils.LogPrefix + "multiple links share the same destination. This can cause problems if using two-way sync." +
                            "\nDestination: " + displayI.DestinationPath +
                            "\nSource: " + displayI.SourcePath +
                            "\nSource: " + displayJ.SourcePath);
                    }
                }
            }
        }

        /************************************************************************************************************************/

        private void DrawMode(Rect rect)
        {
#if LITE
            GUI.enabled = false;
#endif

            rect.width = 35;
            if (GUI.Button(rect, _TwoWay ? TwoWayButton : OneWayButton))
            {
                _TwoWay = !_TwoWay;
            }

            rect.x = rect.xMax; rect.width = EndArea - rect.width - SyncButtonWidth;
            if (GUI.Button(rect, SyncModes[(int)_Mode]))
            {
                GUIUtility.keyboardControl = 0;

                if (Event.current.button == 1)
                {
                    _Mode--;
                    if (_Mode < 0)
                        _Mode = (SyncMode)2;
                }
                else
                {
                    _Mode++;
                    if ((int)_Mode > 2)
                        _Mode = 0;
                }
            }

#if LITE
            GUI.enabled = true;
#endif
        }

        /************************************************************************************************************************/

        private void DrawManageButton(Rect rect)
        {
            bool isManaging = CurrentlyManaging == this;
            if (isManaging != GUI.Toggle(rect, isManaging, "Manage", GUI.skin.button))
            {
                CurrentlyManaging = isManaging ? null : this;
                _ScrollPosition = 0;
                GUIUtility.keyboardControl = 0;
            }
        }

        /************************************************************************************************************************/

        private void DrawSyncButton(Rect rect)
        {
            if (GUI.Button(rect, SyncButton, IsDirty ? Styles.LargeBoldButton : Styles.LargeButton))
            {
                GUIUtility.keyboardControl = 0;

                switch (Event.current.button)
                {
                    case 0:// Left Click = Sync.
                        if (!ShouldAllowSync()) return;
                        SetupTarget();
                        Target.Sync();
                        Link.SaveAll();
                        break;
                    case 1:// Right Click = Full Reimport.
                        if (!ShouldAllowSync()) return;
                        SetupTarget();
                        Target.FullReimport();
                        break;
                    case 2:// Middle Click = Reset Link.
                        if (Target != null)
                        {
                            Source.text = Target.Source;
                            Destination.text = Target.Destination;
                            _TwoWay = Target.TwoWay;
                            _Mode = Target.Mode;
                            _Exclusions.Clear();
                            Target.GetExclusions(_Exclusions);
                        }
                        else
                        {
                            Source.text = "";
                            Destination.text = "";
                            _TwoWay = false;
                            _Mode = default(SyncMode);
                            _Exclusions.Clear();
                        }

                        IsDirty = false;
                        EditorGUI.EndChangeCheck();
                        EditorGUI.BeginChangeCheck();

                        break;
                }
            }
        }

        private bool ShouldAllowSync()
        {
            if (Target != null ||
                !Directory.Exists(Destination.text) ||
                (Directory.GetFiles(Destination.text).Length == 0 &&
                Directory.GetDirectories(Destination.text).Length == 0))
                return true;
            else
                return EditorUtility.DisplayDialog(Utils.ProductName,
                    "The destination folder \"" + Destination.text + "\" is not empty. Are you sure you want to link to that folder?", "Yes", "No");
        }

        private void SetupTarget()
        {
            if (Path.IsPathRooted(Destination.text))
            {
                Destination.text = Utils.AbsoluteToRelative(Destination.text);
                IsDirty = true;
            }

            if (IsDirty)
            {
                if (Target == null)
                {
                    Target = Link.Add(Source, Destination, _TwoWay, _Mode, _Hue, _Exclusions);
                    Link.MatchDisplayOrder(LinkerWindow.LinkDisplays);
                }
                else Target.Setup(Source, Destination, _TwoWay, _Mode, _Hue, _Exclusions);
            }
        }

        public void Sync()
        {
            if (!Link.IsValidSource(Source.text, false) ||
                !Link.IsValidDestination(Destination.text, false) ||
                !ShouldAllowSync())
                return;

            SetupTarget();
            Target.Sync();
        }

        /************************************************************************************************************************/

        public void DrawManagingMode(Rect rect)
        {
            if (Event.current.type == EventType.Repaint)
            {
                Color color = GUI.color;
                GUI.color = Color;

                rect.x = -1;
                rect.width += 2;
                rect.height += 2;
                ReorderableList.defaultBehaviours.boxBackground.Draw(rect, false, false, false, false);

                rect.x = 0;
                rect.width -= 2;
                rect.height -= 2;

                GUI.color = color;
            }

            float bottom = rect.yMax;
            float right = rect.xMax;

            rect.height = DisplayHeight;
            Draw(rect);

            EditorGUI.BeginChangeCheck();

            rect.yMin += DisplayHeight; rect.yMax = bottom;

            float height = (_Exclusions.Count + 1) * RowHeight + ColorSliderHeight;
            if (rect.height < height)
            {
                if (Event.current.type == EventType.ScrollWheel)
                {
                    _ScrollPosition += Event.current.delta.y * (RowHeight / 3);
                    Event.current.Use();
                    return;
                }

                right -= ScrollBarWidth;
                rect.xMin = right;
                _ScrollPosition = GUI.VerticalScrollbar(rect, _ScrollPosition, rect.height, 0, height);
                rect.xMax = rect.xMin; rect.xMin = 0;
            }
            else
            {
                _ScrollPosition = 0;
            }

            GUI.BeginGroup(rect);
            {
                rect.y = -_ScrollPosition;

                // Color Slider.
                rect.x = 0; rect.width = 40; rect.height = ColorSliderHeight;
                GUI.Label(rect, "Color");
                rect.x = rect.width; rect.xMax = right;
                float hue = EditorGUI.Slider(rect, _Hue, 0, 1);
                if (hue != _Hue)
                {
                    _Hue = hue;
                    CalculateColor();
                }

                float sourceWidth;
                GUI.skin.label.CalcMinMaxWidth(Source, out sourceWidth, out sourceWidth);
                sourceWidth -= 8;

                rect.xMin = 0;
                float fieldWidth = rect.width - sourceWidth - OpenFolderButtonWidth - FileButtonWidth - FolderButtonWidth - RemoveButtonWidth;
                if (sourceWidth > fieldWidth)
                    sourceWidth = fieldWidth = (sourceWidth + fieldWidth) * 0.5f;

#if LITE
                GUI.enabled = false;
#endif

                for (int i = 0; i < _Exclusions.Count; i++)
                {
                    rect.y = rect.yMax; rect.height = RowHeight;
                    rect.x = 0; rect.xMax = right - RemoveButtonWidth;
                    _Exclusions[i] = DrawExclusionField(rect, sourceWidth, fieldWidth, _Exclusions[i]);

                    rect.xMin = rect.xMax; rect.width = RemoveButtonWidth;
                    if (GUI.Button(rect, "X"))
                        _Exclusions.RemoveAt(i);
                }

                rect.y = rect.yMax; rect.height = RowHeight;
                rect.x = 0; rect.xMax = right;
                if (GUI.Button(rect, "Add Exclusion"))
                    _Exclusions.Add("");

                string dropPath = CheckDragAndDropExclusion(rect);
                if (dropPath != null)
                {
                    _Exclusions.Add(dropPath);
                    CheckIfDirty();
                }

#if LITE
                GUI.enabled = true;
#endif
            }
            GUI.EndGroup();

            if (EditorGUI.EndChangeCheck())
                CheckIfDirty();
        }

        /************************************************************************************************************************/

        private string DrawExclusionField(Rect rect, float sourceWidth, float fieldWidth, string subPath)
        {
            string path = Source.text + subPath;
            bool exists = !string.IsNullOrEmpty(subPath) &&
                (Directory.Exists(path) || File.Exists(path));

            // Open Folder Button.
            rect.width = OpenFolderButtonWidth;
            GUI.enabled = exists;
            if (GUI.Button(rect, OpenExclusionButton))
            {
                GUIUtility.keyboardControl = 0;
                EditorUtility.RevealInFinder(path);
            }
            GUI.enabled = true;

            // Text Field.
            Color color = GUI.color;
            rect.x = rect.xMax + sourceWidth; rect.width = fieldWidth;
            subPath = EditorGUI.TextField(rect, subPath, exists ? Styles.TextField : Styles.TextFieldError);
            GUI.color = color;

            string dropPath = CheckDragAndDropExclusion(rect);
            if (dropPath != null)
                subPath = dropPath;

            // Source Label.
            rect.y += 2;
            rect.x -= sourceWidth; rect.width = sourceWidth + 4;
            GUI.Label(rect, Source, Styles.RightLabel);
            rect.y -= 2;

            // Browse for File.
            rect.x += sourceWidth + fieldWidth; rect.width = FileButtonWidth;
            if (GUI.Button(rect, FileExclusionBrowseButton))
            {
                if (Utils.BrowseForFile(FileExclusionBrowseButton.tooltip, ref path))
                {
                    GetSourceSubPath(path, ref subPath);
                }

                GUIUtility.keyboardControl = 0;
            }

            // Browse for Folder.
            rect.x = rect.xMax; rect.width = FolderButtonWidth;
            if (GUI.Button(rect, FolderExclusionBrowseButton))
            {
                if (Utils.BrowseForRelativeFolder(FolderExclusionBrowseButton.tooltip, ref path))
                {
                    GetSourceSubPath(path, ref subPath);
                }

                GUIUtility.keyboardControl = 0;
            }

            return subPath;
        }

        /************************************************************************************************************************/

        private string CheckDragAndDropExclusion(Rect rect)
        {
            string dropPath = CheckDragAndDrop(rect, false, null);
            if (dropPath != null)
            {
                return dropPath.Substring(Destination.text.Length, dropPath.Length - Destination.text.Length);
            }
            else
            {
                dropPath = CheckDragAndDrop(rect, true, null);
                if (dropPath != null)
                    GetSourceSubPath(dropPath, ref dropPath);
            }

            return dropPath;
        }

        /************************************************************************************************************************/

        private void GetSourceSubPath(string path, ref string subPath)
        {
            string relativeSource = Utils.AbsoluteToRelative(Source.text);
            if (path.StartsWith(relativeSource))
            {
                subPath = path.Substring(relativeSource.Length, path.Length - relativeSource.Length);
            }
            else
            {
                Debug.LogWarning("A Link exclusion must be within the Source directory.");
            }
        }

        /************************************************************************************************************************/
    }
}