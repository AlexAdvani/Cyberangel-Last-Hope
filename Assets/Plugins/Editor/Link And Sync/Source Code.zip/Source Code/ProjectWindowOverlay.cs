﻿// Link & Sync // Copyright 2016 Kybernetik //

using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace LinkAndSync
{
    internal abstract class ProjectWindowOverlay
    {
        /************************************************************************************************************************/

        public static readonly string AssemblyFolder = Path.GetDirectoryName(Utils.AbsoluteToRelative(typeof(ProjectWindowOverlay).Assembly.Location));

        private static readonly GUIContent
            _Overlay = new GUIContent(AssetDatabase.LoadAssetAtPath<Texture>(AssemblyFolder + "/Overlay.png"), ""),
            _WarningOverlay = new GUIContent(AssetDatabase.LoadAssetAtPath<Texture>(AssemblyFolder + "/Warning Overlay.png"), "");
        private static readonly StringBuilder _TooltipBuilder = new StringBuilder();

        private static readonly Dictionary<string, ProjectWindowOverlay>
            GUIDToOverlay = new Dictionary<string, ProjectWindowOverlay>();
        private static readonly Dictionary<Link, SingleLinkOverlay>
            SingleLinkOverlays = new Dictionary<Link, SingleLinkOverlay>();

        /************************************************************************************************************************/

        private string _Tooltip;

        protected abstract bool IsOutOfDate { get; }

        protected abstract void Sync();

        /************************************************************************************************************************/

        private static bool _Enabled = true;
        public static bool Enabled
        {
            get { return _Enabled; }
            set
            {
                _Enabled = value;
                EditorApplication.projectWindowItemOnGUI -= DrawOverlay;
                if (_Enabled)
                    EditorApplication.projectWindowItemOnGUI += DrawOverlay;
            }
        }

        /************************************************************************************************************************/

        public static void DrawToggle(Rect rect)
        {
            if (_Enabled != GUI.Toggle(rect, Enabled, "Project Window Overlay"))
            {
                Enabled = !_Enabled;
                Link.ForceSave();
            }
        }

        /************************************************************************************************************************/

        private static void DrawOverlay(string guid, Rect selectionRect)
        {
            if (string.IsNullOrEmpty(guid))
                return;

            ProjectWindowOverlay overlay = GetOverlay(guid);
            if (overlay == null)
                return;

            Color color = GUI.color;
            GUI.color = overlay.GetColor();

            HandleMiddleClick(selectionRect, overlay);
            if (Event.current.type == EventType.Used)
                return;

            // Draw the overlay.
            if (selectionRect.height > 16)
            {
                selectionRect.width = selectionRect.height = 16 + 0.3f * selectionRect.width;
            }
            else
            {
                selectionRect.xMin -= 2;
                selectionRect.width = selectionRect.height = 20;
            }

            _Overlay.tooltip = overlay._Tooltip;
            GUI.Label(selectionRect, overlay.IsOutOfDate ? _WarningOverlay : _Overlay);

            GUI.color = color;
        }

        /************************************************************************************************************************/

        private static Rect _TargetRect;

        private static void HandleMiddleClick(Rect selectionRect, ProjectWindowOverlay overlay)
        {
            switch (Event.current.type)
            {
                case EventType.MouseDown:
                    if (Event.current.button == 2 && IsMouseInside(selectionRect))
                    {
                        _TargetRect = selectionRect;
                        Event.current.Use();
                    }
                    break;
                case EventType.MouseDrag:
                    if (_TargetRect == selectionRect && !IsMouseInside(selectionRect))
                    {
                        _TargetRect.Set(0, 0, 0, 0);
                        Event.current.Use();
                    }
                    break;
                case EventType.MouseUp:
                    if (_TargetRect == selectionRect && Event.current.button == 2)
                    {
                        overlay.Sync();
                        _TargetRect.Set(0, 0, 0, 0);
                        Event.current.Use();
                    }
                    break;
                case EventType.Repaint:
                    if (_TargetRect == selectionRect && IsMouseInside(selectionRect))
                    {
                        Color color = GUI.color;
                        color.r *= 0.5f;
                        color.g *= 0.5f;
                        color.b *= 0.5f;
                        GUI.color = color;
                    }
                    break;
            }
        }

        private static bool IsMouseInside(Rect rect)
        {
            return
                !EditorApplication.isCompiling &&
                rect.Contains(Event.current.mousePosition);
        }

        /************************************************************************************************************************/

        private static ProjectWindowOverlay GetOverlay(string guid)
        {
            ProjectWindowOverlay overlay;
            if (GUIDToOverlay.TryGetValue(guid, out overlay))
                return overlay;

            string assetPath = AssetDatabase.GUIDToAssetPath(guid);
            Link singleLink;
            List<Link> multipleLinks;
            Link.GetContainingLink(ref assetPath, out singleLink, out multipleLinks);

            if (multipleLinks != null)
            {
                overlay = new MultiLinkOverlay(multipleLinks);
            }
            else if (singleLink != null)
            {
                SingleLinkOverlay single;
                if (!SingleLinkOverlays.TryGetValue(singleLink, out single))
                {
                    single = new SingleLinkOverlay(singleLink);
                    SingleLinkOverlays.Add(singleLink, single);
                }
                overlay = single;
            }

            GUIDToOverlay.Add(guid, overlay);
            return overlay;
        }

        /************************************************************************************************************************/

        public abstract Color GetColor();

        /************************************************************************************************************************/

        private sealed class SingleLinkOverlay : ProjectWindowOverlay
        {
            private Link _Link;

            public SingleLinkOverlay(Link link)
            {
                _Link = link;
                RebuildTooltip();
            }

            public void RebuildTooltip()
            {
                _Tooltip = "Link Source: " + _Link.Source + "\nMiddle Click to Sync";
            }

            protected override bool IsOutOfDate
            {
                get { return _Link.IsOutOfDate; }
            }

            protected override void Sync()
            {
                _Link.Sync();
                Link.SaveAll();
            }

            public override Color GetColor()
            {
                return Utils.HSBtoRGB(_Link.Hue, 0.75f, 1);
            }
        }

        /************************************************************************************************************************/

        private sealed class MultiLinkOverlay : ProjectWindowOverlay
        {
            private readonly List<Link> Links;

            public MultiLinkOverlay(List<Link> links)
            {
                Links = links;

                _TooltipBuilder.Length = 0;
                _TooltipBuilder.Append("Link Sources: ");
                for (int i = 0; i < links.Count; i++)
                {
                    if (i > 0)
                        _TooltipBuilder.Append(", ");

                    _TooltipBuilder.Append(Utils.RelativeToAbsolute(links[i].Source));
                }
                _TooltipBuilder.Append("\nMiddle Click to Sync");
                _Tooltip = _TooltipBuilder.ToString();
                _TooltipBuilder.Length = 0;
            }

            protected override bool IsOutOfDate
            {
                get
                {
                    for (int i = 0; i < Links.Count; i++)
                        if (Links[i].IsOutOfDate)
                            return true;

                    return false;
                }
            }

            protected override void Sync()
            {
                for (int i = 0; i < Links.Count; i++)
                    Links[i].Sync();
                Link.SaveAll();
            }

            public override Color GetColor()
            {
                return Color.white;
            }
        }

        /************************************************************************************************************************/

        public static void ClearCache()
        {
            GUIDToOverlay.Clear();

            foreach (var overlay in SingleLinkOverlays.Values)
            {
                overlay.RebuildTooltip();
            }

            EditorApplication.RepaintProjectWindow();
        }

        /************************************************************************************************************************/
    }
}